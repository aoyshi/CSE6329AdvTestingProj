package car_rental_app.data;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

import car_rental_app.model.Car;
import car_rental_app.model.ReservationDetails;
import car_rental_app.model.User;
import car_rental_app.util.SQLConnection;

public class CarDAO {

	static SQLConnection DBMgr = SQLConnection.getInstance();
	
	//get car by id
	public static Car getCarById(int carId) {
		Statement stmt = null;   
		Connection conn = null;  
		Car car = new Car();
		try {   
			conn = SQLConnection.getDBConnection();  
			stmt = conn.createStatement();
			String query = " SELECT * from CAR WHERE id = '"+carId+"'";
			ResultSet carList = stmt.executeQuery(query);
			while(carList.next()) {
				int id = carList.getInt("id");
				String name = carList.getString("name");
				int capacity  = carList.getInt("capacity");
				double weekdayRate  = carList.getDouble("weekday_rate");
				double weekendRate  = carList.getDouble("weekday_rate");
				double weeklyRate  = carList.getDouble("weekday_rate");
				double dailyGps  = carList.getDouble("daily_gps");
				double dailySirius  = carList.getDouble("daily_sirius");
				double dailyOnstar  = carList.getDouble("daily_onstar");
				
				car.setCar(id, name, capacity, weekdayRate, weekendRate, weeklyRate, dailyGps, dailyOnstar, dailySirius);
			}
			
			} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		return car;
	}
	
	//manager available cars (sorted by car name)
	public static ArrayList<Car> getAllAvailableCars (String searchStart, String searchEnd) { 	
    	
    	String query = "SELECT id, car.name,capacity,weekday_rate,weekend_rate,weekly_rate,daily_gps,daily_onstar,daily_sirius"
    	     + " FROM car WHERE car.id NOT IN ( SELECT car_id FROM reservation "
	         + " WHERE start_time <= '"+searchEnd+"' and '"+searchStart+"' <= end_time  "
	         + " AND iscanceled!=1 AND isdeleted!=1)"
    		 + " ORDER BY car.name";
    	
		return getCarList(query);
	}
	
	//manager view all cars (sorted by car capacity)
	public static ArrayList<Car> getAllCars () {
	    	String query = "SELECT id, car.name,capacity,weekday_rate,weekend_rate,weekly_rate,daily_gps,daily_onstar,daily_sirius"
	    	     + " FROM car ORDER BY car.capacity";   	
			return getCarList(query);
		}
	
	//customer available cars (sorted by capacity)
	public static ArrayList<Car> getAvailableCarsCustomer(int capacity,
			String searchStart, String searchEnd) {	
    	String query = "SELECT id, car.name,capacity,weekday_rate,weekend_rate,weekly_rate,daily_gps,daily_onstar,daily_sirius"
    	     + " FROM car WHERE capacity>="+capacity+" AND car.id NOT IN ( SELECT car_id FROM reservation "
	         + " WHERE start_time <= '"+searchEnd+"' AND '"+searchStart+"' <= end_time  "
	         + " AND iscanceled!=1 AND isdeleted!=1)"
    		 + " ORDER BY car.capacity";
    	
		return getCarList(query);
	}
	
	//retrieve Car list from DB
	private static ArrayList<Car> getCarList(String query) {
		Statement stmt = null;   
		Connection conn = null;  
		ArrayList<Car> carList = new ArrayList<Car>();

		try {   
			conn = SQLConnection.getDBConnection();  
			stmt = conn.createStatement();
			ResultSet resultList = stmt.executeQuery(query);
			while (resultList.next()) {
				Car car = new Car(); 	
				
				int id = resultList.getInt("id");
				String carName  = resultList.getString("name");
				int capacity  = resultList.getInt("capacity");
				double weekdayRate = resultList.getDouble("weekday_rate");
				double weekendRate = resultList.getDouble("weekend_rate");
				double weeklyRate = resultList.getDouble("weekly_rate");
				double dailyGps  = resultList.getDouble("daily_gps");
				double dailyOnstar  = resultList.getDouble("daily_sirius");
				double dailySirius  = resultList.getDouble("daily_onstar");

				car.setCar(id, carName, capacity, weekdayRate, weekendRate, weeklyRate, dailyGps, dailyOnstar, dailySirius);
				
				carList.add(car);
			} 
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		return carList;
	}
	
	
	
	public static void addNewCar(Car car) {
		Statement stmt = null;   
		Connection conn = SQLConnection.getDBConnection();  
		String addCar = "INSERT INTO CAR (name,capacity,weekday_rate,weekend_rate,weekly_rate,daily_gps,daily_onstar,daily_sirius) ";					
		addCar += " VALUES ('"  
				+ car.getName() + "',"
				+ car.getCapacity() + ","		
				+ car.getWeekdayRate() + ","
				+ car.getWeekendRate() + "," 
				+ car.getWeeklyRate()  + ","
				+ car.getDailyGps() + ","
				+ car.getDailyOnstar() + ","		
				+ car.getDailySirius() + ")" ;
		try {   
		conn = SQLConnection.getDBConnection();  
		conn.setAutoCommit(false);   
		stmt = conn.createStatement();
		stmt.executeUpdate(addCar);
		conn.commit();					 
	} catch (SQLException sqle) { 
		sqle.printStackTrace();
	} finally {
		try {
			conn.close();
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		};
	}
	}	
	
	//check if a car with same name already exists in DB or not
	public static boolean uniqueCarName(String name) {  
		Statement stmt = null;   
		Connection conn = null;  
		try {   
			conn = SQLConnection.getDBConnection();  
			stmt = conn.createStatement();
			String searchCarName = " SELECT * from CAR WHERE NAME = '"+name+"'";
			ResultSet carList = stmt.executeQuery(searchCarName);
			ArrayList<Car> carListInDB = new ArrayList<Car>();
			while (carList.next()) {
				Car car = new Car(); 
				carListInDB.add(car);	 
			} 
			return (carListInDB.isEmpty());
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				conn.close();
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}};
		return false;
	}
	
}