package car_rental_app.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import car_rental_app.data.CarDAO;
import car_rental_app.model.Car;

@WebServlet("/ViewAllCarsController")
public class ViewAllCarsController extends HttpServlet {

	private static final long serialVersionUID = 7L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String action = request.getParameter("action");
		String url="";
		
        //List all cars
		if (action.equalsIgnoreCase("listCars")) {
			ArrayList<Car> carList = new ArrayList<Car>();
			carList=CarDAO.getAllCars(); 
			session.setAttribute("Cars", carList);	
			url="/viewAllCars.jsp";
		}
		else if(action.equalsIgnoreCase("goHome")) {
			session.removeAttribute("Cars");
			url="/managerHome.jsp";
		}
		else // redirect all other gets to post
			doPost(request,response);
		
		getServletContext().getRequestDispatcher(url).forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}
}