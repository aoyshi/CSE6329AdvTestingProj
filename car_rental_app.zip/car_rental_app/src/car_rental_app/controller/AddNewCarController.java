package car_rental_app.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import car_rental_app.data.CarDAO;
import car_rental_app.model.*;

@WebServlet("/AddNewCarController")
public class AddNewCarController extends HttpServlet {

	private static final long serialVersionUID = 6L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		String action = request.getParameter("action");
		String url = "/addNewCar.jsp";
		
		if(action.equalsIgnoreCase("addNewCar")) {
			if (request.getParameter("addCarBtn")!=null) 
			{
				Car car = new Car();	
				car.setCar(request.getParameter("name"), request.getParameter("capacity"), 
						request.getParameter("weekdayRate"), request.getParameter("weekendRate"), 
						request.getParameter("weeklyRate"), request.getParameter("dailyGps"), 
						request.getParameter("dailyOnstar"), request.getParameter("dailySirius"));
				CarErrorMsgs CerrorMsgs = new CarErrorMsgs();
				car.validateCar(car, CerrorMsgs);
				session.setAttribute("Car",car);
				session.setAttribute("errorMsgs",CerrorMsgs);
				if (CerrorMsgs.getErrorMsg().equals("")) {
					CarDAO.addNewCar(car); //save car if no errors
					session.removeAttribute("Car");
					session.removeAttribute("errorMsgs");
				}
			}
			else //done button pressed
			{
				session.removeAttribute("Car");
				session.removeAttribute("errorMsgs");
				url = "/managerHome.jsp";
			}
		}
		
		else if(action.equalsIgnoreCase("goHome")) {
			session.removeAttribute("Car");
			session.removeAttribute("errorMsgs");
			url="/managerHome.jsp";
		}
		
		else //redirect all other posts to get
			doGet(request,response);
		
		getServletContext().getRequestDispatcher(url).forward(request, response);
			
	}
}