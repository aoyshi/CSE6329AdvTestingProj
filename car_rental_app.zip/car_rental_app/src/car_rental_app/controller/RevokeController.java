package car_rental_app.controller;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import car_rental_app.data.UserDAO;
import car_rental_app.model.*;

@WebServlet("/RevokeController")
public class RevokeController extends HttpServlet {

	private static final long serialVersionUID = 5L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		HttpSession session = request.getSession();		
		String url="/revokeRenter.jsp";

		if (action.equalsIgnoreCase("revokeRenter")) //search username
		{
			//display list of revoked renters
			ArrayList<String> revokedUsers = UserDAO.getAllRevokedUsers();
			session.setAttribute("USERS",revokedUsers);
			
			//if revoke btn pressed, validate entered username, then update list
			if (request.getParameter("revokeBtn")!=null) 
			{
				User user = new User();
				user.setUsername(request.getParameter("username"));
				UserErrorMsgs UerrorMsgs = new UserErrorMsgs();
				user.verifyUsername(user, UerrorMsgs);
				session.setAttribute("User",user);
				session.setAttribute("errorMsgs",UerrorMsgs);	
				
				if (UerrorMsgs.getErrorMsg().equals(""))  
				{ 
					//revoke the user
					user = UserDAO.getUser(request.getParameter("username"));
					user.setIsRevoked(1);
					UserDAO.updateUser(user);
					//refresh list
					revokedUsers = UserDAO.getAllRevokedUsers();
					session.setAttribute("USERS",revokedUsers);
					url = "/revokeRenter.jsp";	
			    }
			} 
			
		}
		
		else if (action.equalsIgnoreCase("goHome")) 
		{
			session.removeAttribute("User");
			session.removeAttribute("errorMsgs");
			session.removeAttribute("USERS");
			url = "/adminHome.jsp"; //redirect to home page
		}
		
		else // redirect all other posts to get
		  doGet(request,response); 
			
		getServletContext().getRequestDispatcher(url).forward(request, response);
		
   }
}
