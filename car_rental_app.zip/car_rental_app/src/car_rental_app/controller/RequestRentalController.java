package car_rental_app.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import car_rental_app.model.ReservationErrorMsgs;
import car_rental_app.model.CarErrorMsgs;
import car_rental_app.data.ReservationDAO;
import car_rental_app.data.CarDAO;
import car_rental_app.data.UserDAO;
import car_rental_app.model.ReservationDetails;
import car_rental_app.model.Reservation;
import car_rental_app.model.Car;
import car_rental_app.model.User;



@WebServlet("/RequestRentalController")
public class RequestRentalController extends HttpServlet {
	private static final long serialVersionUID = 11L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String action = request.getParameter("action");
		String url="/requestRental.jsp"; 
		
		ArrayList<Car> carList = new ArrayList<Car>(); 
		
		//List available cars to rent 
		if (action.equalsIgnoreCase("requestRental"))  
		{		
			User user = (User) session.getAttribute("currentUser");
			//dont let revoked renters access form
			if (user.getIsRevoked() == 1)
				url="/revokedPage.jsp";
					
			if(request.getParameter("searchBtn")!=null) {
				
				//remove results from previous searches
				session.removeAttribute("Reservation");
				session.removeAttribute("Car");
				session.removeAttribute("RESERVATIONS");
				session.removeAttribute("CARS");
				
				String selectedStartTime = request.getParameter("startTime");
				String selectedEndTime = request.getParameter("endTime");
				String capacity = request.getParameter("capacity");
				
				//validate start/end time
				Reservation reservationTemp = new Reservation();
				reservationTemp.setStartTimeAsString(selectedStartTime);
				reservationTemp.setEndTimeAsString(selectedEndTime);	
				
				ReservationErrorMsgs RerrorMsgs = new ReservationErrorMsgs();
				reservationTemp.validateRequestTimes(reservationTemp, RerrorMsgs);
				session.setAttribute("Reservation",reservationTemp);
				session.setAttribute("errorMsgs",RerrorMsgs);
				
				//validate capacity entered
				Car carTemp = new Car();
				carTemp.setCapacityAsString(capacity);
				CarErrorMsgs CerrorMsgs = new CarErrorMsgs();
				carTemp.validateCapacity(carTemp, CerrorMsgs);
				session.setAttribute("userCapacity",capacity);
				session.setAttribute("CerrorMsgs",CerrorMsgs);
				
								
				if (RerrorMsgs.getErrorMsg().equals("") && CerrorMsgs.getErrorMsg().equals("")) {	
					session.removeAttribute("errorMsgs");
					carList = CarDAO.getAvailableCarsCustomer(Integer.parseInt(capacity),
							reservationTemp.getStartTimeAsString(), reservationTemp.getEndTimeAsString()); 
					
					ArrayList<ReservationDetails> rentalList = new ArrayList<ReservationDetails>();
					
					//for every available car, construct potential reservation
					for(Car car : carList) {
						ReservationDetails reservationDetails = new ReservationDetails();
						reservationDetails.setStartTime(selectedStartTime);
						reservationDetails.setEndTime(selectedEndTime);	
						reservationDetails.setCarName(car.getName());
						reservationDetails.setCapacity(Integer.parseInt(capacity));
						
						double totalPrice = reservationTemp.calculateTotalPrice(car);
						reservationDetails.setTotalPrice(totalPrice);	
						
						rentalList.add(reservationDetails);
					}
					
					session.setAttribute("RESERVATIONS", rentalList);
					session.setAttribute("CARS", carList);
				}								
			}				
			else if(request.getParameter("clearBtn")!=null) {
				session.removeAttribute("errorMsgs");
				session.removeAttribute("CerrorMsgs");
				session.removeAttribute("Reservation");
				session.removeAttribute("Car");
				session.removeAttribute("RESERVATIONS");
				session.removeAttribute("CARS");
				session.removeAttribute("userCapacity");
			}			
		}
		
		else if (action.equalsIgnoreCase("reserveRental")) 
		{   	
			    url="/addFeatures.jsp";					    
			    
				int carId = Integer.parseInt(request.getParameter("carId"));
				String startTime = request.getParameter("startTime");
				String endTime = request.getParameter("endTime");
				double totalPrice = Double.parseDouble(request.getParameter("totalPrice"));
				//get car from car id
				Car car = CarDAO.getCarById(carId);
				
				//construct partial reservation (to send to next page)
				Reservation reservation = new Reservation();
				reservation.setCarId(carId);
				reservation.setStartAndEndTimes(startTime, endTime);
			
				//set total price
				reservation.setTotalPrice(totalPrice);
				
				//pass to session
				session.setAttribute("Car", car);
				session.setAttribute("Reservation", reservation);					

		}
		
		else if (action.equalsIgnoreCase("addFeatures")) 
		{
			if(request.getParameter("continueBtn")!=null) {
				url="/payForRental.jsp";					
				//get car
				Car car = (Car) session.getAttribute("Car");
				//get reservation
				Reservation reservation = (Reservation) session.getAttribute("Reservation");		
				
				//get & set extras added
				String[] extras = request.getParameterValues("extras");			
				
				  if(extras != null)
				  {
					for(String extra : extras) 
					{
						if(extra.equalsIgnoreCase("gps"))
							reservation.setHasGps(1);
						if(extra.equalsIgnoreCase("sirius"))
							reservation.setHasSirius(1);			
						if(extra.equalsIgnoreCase("onstar"))
							reservation.setHasOnstar(1);
					}
				  }	
				
				User renter = (User) session.getAttribute("currentUser");
				int age = renter.getAge();
				int applyDiscount = renter.getAacMembership();
								
				double finalPrice = reservation.calculateFinalPrice(car,age,applyDiscount);
				reservation.setTotalPrice(finalPrice);
				
				session.setAttribute("Car",car);
				session.setAttribute("Reservation", reservation);
			}				
			
			else if(request.getParameter("backBtn")!=null) {
				session.removeAttribute("Payment");
				session.removeAttribute("errorMsgs");
				session.removeAttribute("CerrorMsgs");	
				url = "/requestRental.jsp"; //redirect to request rental list
			}
		}
		
		else if (action.equalsIgnoreCase("goHome")) 
		{
			session.removeAttribute("Reservation");
			session.removeAttribute("Car");
			session.removeAttribute("Payment");
			session.removeAttribute("errorMsgs");
			session.removeAttribute("CerrorMsgs");
			session.removeAttribute("RESERVATIONS");
			session.removeAttribute("CARS");
			session.removeAttribute("userCapacity");
			
			url = "/customerHome.jsp"; //redirect to home page
		}
			
		else // redirect all other posts to get
			doGet(request,response);
		
		getServletContext().getRequestDispatcher(url).forward(request, response);

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);		
	}

}

