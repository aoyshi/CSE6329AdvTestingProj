package car_rental_app.controller;
 
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import car_rental_app.data.UserDAO;
import car_rental_app.model.*;

@WebServlet("/EditAnotherUserController")
public class EditAnotherUserController extends HttpServlet {

	private static final long serialVersionUID = 5L; 
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		HttpSession session = request.getSession();		
		String url="/searchUserProfile.jsp"; 

		//search for user profile and display it
		if (action.equalsIgnoreCase("displayUserProfile")) 
		{			
			User user = new User();
			user.setUsername(request.getParameter("username"));
			UserErrorMsgs UerrorMsgs = new UserErrorMsgs();
			user.verifyUsername(user, UerrorMsgs);
			session.setAttribute("User",user);
			session.setAttribute("errorMsgs",UerrorMsgs);	
			
			if (UerrorMsgs.getErrorMsg().equals("")) { //username exists		
				//redirect to user profile
				url = "/userProfile.jsp";
				user = UserDAO.getUser(request.getParameter("username"));				
				session.setAttribute("User", user); //pre-populate fields 
			}			
		}	 
		 
		//edit the displayed user profile
		else if (action.equalsIgnoreCase("editUserProfile")) 
		{
			url="/userProfile.jsp";
			if (request.getParameter("saveBtn")!=null) 
			{
				session.removeAttribute("successMsg"); //msg from previous saves
				User user = UserDAO.getUser(request.getParameter("username"));
				
				user.setFirstName(request.getParameter("firstName"));
				user.setLastName(request.getParameter("lastName"));
				user.setUsername(request.getParameter("username"));
				user.setPassword(request.getParameter("password"));
				user.setEmail(request.getParameter("email"));
				user.setUtaId(request.getParameter("utaId"));
				user.setAgeAsString(request.getParameter("age")); 
				user.setAacMembership(Integer.parseInt(request.getParameter("aac"))); //safe, aacMem is strictly 0/1 from jsp form radio buttons
				user.setRole(request.getParameter("role"));				
				
				UserErrorMsgs UerrorMsgs = new UserErrorMsgs();
				user.validateUser(user, UerrorMsgs, action);
				session.setAttribute("User",user);
				session.setAttribute("errorMsgs",UerrorMsgs);
				
				if (UerrorMsgs.getErrorMsg().equals("")) {
					UserDAO.updateUser(user); 
					session.removeAttribute("errorMsgs");					
					//if successful, stay on page and show confirmation msg
					session.setAttribute("successMsg", "Changes successfully saved.");
				}
			}
			
			else if (request.getParameter("cancelBtn")!=null)  { //cancel button pressed, dont update
				session.removeAttribute("User");
				session.removeAttribute("errorMsgs");
				session.removeAttribute("successMsg");
				url = "/adminHome.jsp";			
			}
		}

		else if (action.equalsIgnoreCase("goHome")) 
		{
			session.removeAttribute("User");
			session.removeAttribute("errorMsgs");
			session.removeAttribute("USERS");
			session.removeAttribute("successMsg");
			url = "/adminHome.jsp"; //redirect to home page
		}
		
		//else // redirect all other posts to get
		  //doGet(request,response); 
			
		getServletContext().getRequestDispatcher(url).forward(request, response);
		
   }
}
