package car_rental_app.tests;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import car_rental_app.model.Car;
import car_rental_app.model.CarErrorMsgs;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class CarTest {
	Car car;
	CarErrorMsgs cErrorMsgs;
	
	@Before
	public void setUp() throws Exception {
		car = new Car();
		cErrorMsgs = new CarErrorMsgs();
	}
	
	@FileParameters("src/Car_Test_Cases.csv")
	@Test
	public void test(int testcase,int id,String name,String capacityAsString,String weekdayRateAsString,
			String weekendRateAsString,String weeklyRateAsString,String dailyGpsAsString,
			String dailyOnstarAsString,String dailySiriusAsString,String errorMsg,String nameError,
			String capacityError,String weekdayRateError,String weekendRateError,String weeklyRateError,
			String dailyGpsError,String dailyOnstarError,String dailySiriusError,
			int capacity,double weekdayRate, double weekendRate,double weeklyRate,
			double dailyGps,double dailyOnstar,double dailySirius) {		
		
		car.setId(id);
		car.setName(name);
		car.setCapacityAsString(capacityAsString);
		car.setWeekdayRateAsString(weekdayRateAsString);
		car.setWeekendRateAsString(weekendRateAsString);
		car.setWeeklyRateAsString(weeklyRateAsString);
		car.setDailyGpsAsString(dailyGpsAsString);
		car.setDailyOnstarAsString(dailyOnstarAsString);
		car.setDailySiriusAsString(dailySiriusAsString);
		
		car.validateCar(car, cErrorMsgs);
		car.validateCapacity(car, cErrorMsgs);
		
		assertEquals(errorMsg,cErrorMsgs.getErrorMsg());
		assertEquals(nameError,cErrorMsgs.getNameError());
		assertEquals(capacityError,cErrorMsgs.getCapacityError());
		assertEquals(weekdayRateError,cErrorMsgs.getWeekdayRateError());
		assertEquals(weekendRateError,cErrorMsgs.getWeekendRateError());
		assertEquals(weeklyRateError,cErrorMsgs.getWeeklyRateError());
		assertEquals(dailyGpsError,cErrorMsgs.getDailyGpsError());
		assertEquals(dailyOnstarError,cErrorMsgs.getDailyOnstarError());
		assertEquals(dailySiriusError,cErrorMsgs.getDailySiriusError());
		
		assertEquals(capacity,car.getCapacity());
		assertEquals(weekdayRate,car.getWeekdayRate(),2);
		assertEquals(weekendRate,car.getWeekendRate(),2);
		assertEquals(weeklyRate,car.getWeeklyRate(),2);
		assertEquals(dailyGps,car.getDailyGps(),2);
		assertEquals(dailyOnstar,car.getDailyOnstar(),2);
		assertEquals(dailySirius,car.getDailySirius(),2);
		
		assertEquals(id,car.getId());
		
	    	    
	}

}
