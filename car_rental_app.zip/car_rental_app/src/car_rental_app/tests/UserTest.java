package car_rental_app.tests;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import car_rental_app.model.User;
import car_rental_app.model.UserErrorMsgs;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class UserTest {

	User user;
	UserErrorMsgs uErrorMsgs;
	
	@Before
	public void setUp() throws Exception {
		user = new User();
		uErrorMsgs = new UserErrorMsgs();
	}

	@FileParameters("src/User_Test_Cases.csv")
	@Test
	public void testRegister(int testCaseNumber, int id, String firstName, String lastName, 
			String utaId, String username, String password, String email, String ageAsString, 
			int aacMembership, String role, int isRevoked, String action, 
			int age, String errorMsg, String firstNameError, String lastNameError, 
			String utaIdError, String usernameError, String passwordError, 
			String emailError, String ageError) {		

		user.setId(id);
		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setUsername(username);
		user.setPassword(password);
		user.setEmail(email);
		user.setUtaId(utaId);
		user.setAgeAsString(ageAsString); 
		user.setAacMembership(aacMembership); 
		user.setRole(role);
		user.setIsRevoked(isRevoked);	
		
		user.validateUser(user, uErrorMsgs, action);	
		
		assertEquals(errorMsg,uErrorMsgs.getErrorMsg());
		assertEquals(firstNameError,uErrorMsgs.getFirstNameError());
		assertEquals(lastNameError,uErrorMsgs.getLastNameError());
		assertEquals(utaIdError,uErrorMsgs.getUtaIdError());
		assertEquals(usernameError,uErrorMsgs.getUsernameError());
		assertEquals(passwordError,uErrorMsgs.getPasswordError());
		assertEquals(emailError,uErrorMsgs.getEmailError());
		assertEquals(ageError,uErrorMsgs.getAgeError());	
		assertEquals(isRevoked,user.getIsRevoked());
		assertEquals(age,user.getAge());
		assertEquals(id,user.getId());
		assertEquals(role,user.getRole());
		assertEquals(aacMembership,user.getAacMembership());		
	}
	
	@FileParameters("src/User_Test_Cases_Login.csv")
	@Test
	public void testLogin(int testCaseNumber, String username, String password, 
			String errorMsg, String usernameError, String passwordError) {	
		user.setUsername(username);
		user.setPassword(password);	
		
		user.verifyPassword(user, uErrorMsgs);
		user.verifyUsername(user, uErrorMsgs);	
		
		assertEquals(errorMsg,uErrorMsgs.getErrorMsg());
		assertEquals(usernameError,uErrorMsgs.getUsernameError());
		assertEquals(passwordError,uErrorMsgs.getPasswordError());		
	}
}