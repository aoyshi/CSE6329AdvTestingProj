package car_rental_app.tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import car_rental_app.model.User;
import car_rental_app.model.UserErrorMsgs;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class UserTest {

	//declare variable here
	User user;
	UserErrorMsgs uErrorMsgs;
	
	@Before
	public void setUp() throws Exception {
		//instantiate variable here
		user = new User();
		uErrorMsgs = new UserErrorMsgs();
	}

	@FileParameters("src/User_Test_Cases_Register.csv")
	@Test
	public void testRegister(int testCaseNumber, int id, String firstName, String lastName, 
			String utaId, String username, String password, String email, String ageAsString, 
			int aacMembership, String role, int isRevoked, String action, 
			int age, String errorMsg, String firstNameError, String lastNameError, 
			String utaIdError, String usernameError, String passwordError, 
			String emailError, String ageError) {		
		//set user attributes
		user.setId(id);
		user.setFirstName(firstName);
		user.setLastName(lastName);
		user.setUsername(username);
		user.setPassword(password);
		user.setEmail(email);
		user.setUtaId(utaId);
		user.setAgeAsString(ageAsString); //will be verified if int
		user.setAacMembership(aacMembership); //safe, aacMem is strictly 0/1 from jsp form radio buttons
		user.setRole(role);
		user.setIsRevoked(isRevoked);	
		
		//validate user
		user.validateUser(user, uErrorMsgs, action);	
		//assert for age conversion
		assertEquals(age,user.getAge());		
		//asserts for error msgs
		assertEquals(errorMsg,uErrorMsgs.getErrorMsg());
		assertEquals(firstNameError,uErrorMsgs.getFirstNameError());
		assertEquals(lastNameError,uErrorMsgs.getLastNameError());
		assertEquals(utaIdError,uErrorMsgs.getUtaIdError());
		assertEquals(usernameError,uErrorMsgs.getUsernameError());
		assertEquals(passwordError,uErrorMsgs.getPasswordError());
		assertEquals(emailError,uErrorMsgs.getEmailError());
		assertEquals(ageError,uErrorMsgs.getAgeError());	
		
		//unsure about this bit (ask prof)
		assertEquals(isRevoked,user.getIsRevoked());
		assertEquals(id,user.getId());
		assertEquals(role,user.getRole());
		assertEquals(aacMembership,user.getAacMembership());
		
	}
	
	@FileParameters("src/User_Test_Cases_Login.csv")
	@Test
	public void testLogin(int testCaseNumber, String username, String password, 
			String errorMsg, String usernameError, String passwordError) {	
		user.setUsername(username);
		user.setPassword(password);	
		user.verifyPassword(user, uErrorMsgs);
		user.verifyUsername(user, uErrorMsgs);	
		assertEquals(errorMsg,uErrorMsgs.getErrorMsg());
		assertEquals(usernameError,uErrorMsgs.getUsernameError());
		assertEquals(passwordError,uErrorMsgs.getPasswordError());		
	}

}