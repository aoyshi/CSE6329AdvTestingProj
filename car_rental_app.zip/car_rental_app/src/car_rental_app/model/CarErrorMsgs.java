package car_rental_app.model;

public class CarErrorMsgs {
	private String errorMsg;
	private String nameError;
	private String capacityError;
	private String weekdayRateError;
	private String weekendRateError;
	private String weeklyRateError;
	private String dailyGpsError;
	private String dailyOnstarError;
	private String dailySiriusError;
	
	public CarErrorMsgs () { 
		this.nameError="";
		this.capacityError="";
		this.weekdayRateError="";
		this.weekendRateError="";
		this.weeklyRateError="";
		this.dailyGpsError="";
		this.dailyOnstarError="";
		this.dailySiriusError="";
		this.errorMsg="";
	}
	public void setErrorMsg() {
		if (!nameError.equals("") || !capacityError.equals("") || !weekdayRateError.equals("") 
			|| !weekendRateError.equals("") || !weeklyRateError.equals("") ||!dailyGpsError.equals("") 
		    || !dailyOnstarError.equals("") || !dailySiriusError.equals(""))
		  errorMsg="Please correct the following errors";
	}	
	public String getErrorMsg() {return errorMsg;}
	public String getCapacityError() {return capacityError;}
	public void setCapacityError(String capacityError) {this.capacityError = capacityError;}
	public String getDailyGpsError() {return dailyGpsError;}
	public void setDailyGpsError(String dailyGpsError) {this.dailyGpsError = dailyGpsError;}
	public String getDailyOnstarError() {return dailyOnstarError;}
	public void setDailyOnstarError(String dailyOnstarError) {this.dailyOnstarError = dailyOnstarError;}
	public String getDailySiriusError() {return dailySiriusError;}
	public void setDailySiriusError(String dailySiriusError) {this.dailySiriusError = dailySiriusError;}
	public String getNameError() {return nameError;}	
	public void setNameError(String nameError) {this.nameError = nameError;}
	public String getWeekdayRateError() {return weekdayRateError;}	
	public void setWeekdayRateError(String weekdayRateError) {this.weekdayRateError = weekdayRateError;}
	public String getWeekendRateError() {return weekendRateError;}	
	public void setWeekendRateError(String weekendRateError) {this.weekendRateError = weekendRateError;}
	public String getWeeklyRateError() {return weeklyRateError;}	
	public void setWeeklyRateError(String weeklyRateError) {this.weeklyRateError = weeklyRateError;}
}