package car_rental_app.model;

/* this class is used simply for jsp-displaying purposes. 
 * not the true reservation model 
 * does not contain validations
 */

import java.io.Serializable;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class ReservationDetails implements Serializable{

	private static final long serialVersionUID = 6L;
	
	private int id; //rental confirmation number
	private String username;
	private String carName;
	private int capacity;
	private String startTime;
	private String endTime;
	private int hasGps;
	private int hasOnstar;
	private int hasSirius;
	private double totalPrice;
	
	private String additionalFeatures="";

	public void setReservationDetails (int id, String username, String carName, int capacity, 
			String startTime, String endTime, int hasGps, int hasOnstar, int hasSirius, double totalPrice) {
		
		this.id=id;
		this.username = username;
		this.carName = carName;
		this.capacity = capacity;		
		this.startTime = startTime.replace('T', ' ');		
		this.endTime = endTime.replace('T', ' ');
		this.hasGps = hasGps;
		this.hasOnstar = hasOnstar;
		this.hasSirius =  hasSirius;
		this.totalPrice = totalPrice;
		
		if(hasGps==1)
			additionalFeatures += "GPS  ";
		if(hasOnstar==1)
			additionalFeatures += "OnStar  ";
		if(hasSirius==1)
			additionalFeatures += "SiriusXM  ";
		
	}		
	
	public String getAdditionalFeatures() {
		return additionalFeatures;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public double getTotalPrice() {
		return totalPrice;
	}
	
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	
	
	public int getCapacity(){
		return capacity;
	}

	public void setCapacity(int capacity){
		this.capacity=capacity;
	}
	public String getCarName(){
		return carName;
	}

	public void setCarName(String carName){
		this.carName=carName;
	}
	
	public String getStartTime() {
		return startTime;
	}
	
	public void getUsername(String username){
		this.username=username;
	}
	
	public String getUsername() {
		return username;
	}
	
	public void setStartTime(String startTime) {
		 this.startTime=startTime;
	}
	
	public String getEndTime() {
		return endTime;
	}
	
	public void setEndTime(String endTime) {
		 this.endTime=endTime;
	}
	
	public int getHasGps() {
		return hasGps;
	}
	
	public void setHasGps(int hasGps){
		this.hasGps=hasGps;
	}
	
	public int getHasOnstar() {
		return hasOnstar;
	}
	
	public void setHasOnstar(int hasOnstar){
		this.hasOnstar=hasOnstar;
	}
	
	public int getHasSirius() {
		return hasSirius;
	}
	
	public void setHasSirius(int hasSirius){
		this.hasSirius=hasSirius;
	}
	

}
