package car_rental_app.junit;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import car_rental_app.data.CarDAO;
import car_rental_app.model.Car;
import car_rental_app.model.Reservation;
import car_rental_app.model.ReservationErrorMsgs;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class ReservationTest {

	Car car;
	Reservation reservation;
	ReservationErrorMsgs rErrorMsgs;
	
	@Before
	public void setUp() throws Exception {
		car = new Car();
		reservation = new Reservation();
		rErrorMsgs = new ReservationErrorMsgs();
	}
	
	@FileParameters("tests/csv/Reservation_Price_Test_Cases.csv")
	@Test
	public void test(int testCaseNumber, int id, String carId, String paymentId, 
			String startTimeAsString,String endTimeAsString, double totalPrice, int applyDiscount, String hasGps, 
			String hasOnstar, String hasSirius,String isCanceled,String isDeleted,
			int age, double expTotalPrice, String expAdditionalFeatures, double expFinalPrice,
			String startTime, String endTime) 
	{		
		reservation.setReservation(carId,paymentId,startTimeAsString,endTimeAsString,hasGps,hasOnstar,
			 hasSirius,isCanceled,isDeleted,totalPrice);
		reservation.setId(id);
		car = CarDAO.getCarById(reservation.getCarId());
		reservation.setTotalPrice(reservation.calculateTotalPrice(car));
		
		assertEquals(expTotalPrice,reservation.getTotalPrice(),2);
		
		reservation.setStartAndEndTimes(startTimeAsString,endTimeAsString);
		double finalPrice = reservation.calculateFinalPrice(car, age, applyDiscount);
		
		assertEquals(expAdditionalFeatures, reservation.getAdditionalFeatures());
		assertEquals(expFinalPrice, finalPrice, 2);
		assertEquals(reservation.getStartTime().toString(), startTime);
		assertEquals(reservation.getEndTime().toString(), endTime);
		assertEquals(id,reservation.getId());
		assertEquals(Integer.parseInt(paymentId),reservation.getPaymentId());
		assertEquals(Integer.parseInt(hasGps),reservation.getHasGps());
		assertEquals(Integer.parseInt(hasOnstar),reservation.getHasOnstar());
		assertEquals(Integer.parseInt(hasSirius),reservation.getHasSirius());
		assertEquals(Integer.parseInt(isCanceled),reservation.getIsCanceled());
		assertEquals(Integer.parseInt(isDeleted),reservation.getIsDeleted());
		
	}
	
	
	@FileParameters("tests/csv/Reservation_View_Time_Test_Cases.csv")
	@Test
	public void testViewDTs(int testCaseNumber, String startDT, String endDT, boolean flag,
			String errorMsgs, String startError, String endError) {

		reservation.setStartTimeAsString(startDT);
		reservation.setEndTimeAsString(endDT);
		
		reservation.validateViewFilterTimes(reservation, rErrorMsgs);
		
		//asserts for error msgs
		assertEquals(errorMsgs,rErrorMsgs.getErrorMsg());
		assertEquals(startError,rErrorMsgs.getStartTimeError());
		assertEquals(endError,rErrorMsgs.getEndTimeError());
	    	     
	}
	
	@FileParameters("tests/csv/Reservation_Request_Times_Test_Cases.csv")
	@Test
	public void testRequestDTs(int testCaseNumber, String startDT, String endDT, boolean flag,
			String errorMsgs, String startError, String endError) {

		reservation.setStartTimeAsString(startDT);
		reservation.setEndTimeAsString(endDT);
		
		reservation.validateRequestTimes(reservation, rErrorMsgs);
		
		//asserts for error msgs
		assertEquals(errorMsgs,rErrorMsgs.getErrorMsg());
		assertEquals(startError,rErrorMsgs.getStartTimeError());
		assertEquals(endError,rErrorMsgs.getEndTimeError());
	    	    
	}
}