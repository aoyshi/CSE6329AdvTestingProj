package car_rental_app.junit;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import car_rental_app.data.CarDAO;
import car_rental_app.data.ReservationDAO;
import car_rental_app.model.Car;
import car_rental_app.model.ReservationDetails;
import car_rental_app.model.ReservationErrorMsgs;
import junitparams.FileParameters;
import junitparams.JUnitParamsRunner;

@RunWith(JUnitParamsRunner.class)
public class ReservationDetailsTest {

	ReservationDetails reservationDetails;
	
	@Before
	public void setUp() throws Exception {
		reservationDetails = new ReservationDetails();
	}
	
	@FileParameters("tests/csv/Reservation_Details_Test_Cases.csv")
	@Test
	public void test(int tcNumber, int resId, String carId, String paymentId, 
			String username, String carName, int capacity, String startTime, String endTime,
			int hasGps, int hasOnstar, int hasSirius,double totalPrice, String additionalFeatures) 
	{		
		reservationDetails = ReservationDAO.getReservationById(resId); //covers all setters
		//asserts cover getters
		assertEquals(resId, reservationDetails.getId());
		assertEquals(carName, reservationDetails.getCarName());
		assertEquals(username, reservationDetails.getUsername());
		assertEquals(capacity, reservationDetails.getCapacity());
		assertEquals(startTime, reservationDetails.getStartTime());
		assertEquals(endTime, reservationDetails.getEndTime());
		assertEquals(hasGps, reservationDetails.getHasGps());
		assertEquals(hasOnstar, reservationDetails.getHasOnstar());
		assertEquals(hasSirius, reservationDetails.getHasSirius());
		assertEquals(totalPrice, reservationDetails.getTotalPrice(),2);
		assertEquals(additionalFeatures, reservationDetails.getAdditionalFeatures());
		
	}

}