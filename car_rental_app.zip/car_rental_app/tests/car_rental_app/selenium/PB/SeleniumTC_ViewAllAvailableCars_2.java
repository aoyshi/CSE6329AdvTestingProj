package car_rental_app.selenium.PB;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import functions.App_BusinessFunctions;

public class SeleniumTC_ViewAllAvailableCars_2 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));

    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));

  }

  @Test
  public void seleniumTC_ViewAllAvailableCars_2() throws Exception {
    driver.get(sAppURL);
    //login with correct creds
    App_BF_Login(driver,"manager","Hi..There..001");

    //Travel to View all Cars Page
    driver.findElement(By.linkText(prop.getProperty("Lnk_ManagerHome_ViewAvailableCars"))).click();    
    //check Title of Page
    assertEquals("View Available Cars", driver.getTitle());
    //Check Table Sanity
    App_BF_ViewAvailableCars_Filter(driver,"","");
	//Check if error messages are set properly    
	assertEquals("Please correct the following errors", driver.findElement(By.name(prop.getProperty("Lbl_View_Available_Form_Error"))).getAttribute("value"));
	assertEquals("Start Date-Time cannot be blank", driver.findElement(By.name(prop.getProperty("Lbl_View_Available_Start_Error"))).getAttribute("value"));
	assertEquals("End Date-Time cannot be blank", driver.findElement(By.name(prop.getProperty("Lbl_View_Available_End_Error"))).getAttribute("value"));
    //logout
    App_BF_Logout(driver);
  }
  
  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
