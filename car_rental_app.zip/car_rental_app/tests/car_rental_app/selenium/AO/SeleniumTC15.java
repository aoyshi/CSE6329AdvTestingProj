package car_rental_app.selenium.AO;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

import car_rental_app.data.CarDAO;
import car_rental_app.data.UserDAO;
import car_rental_app.model.User;

import java.util.Properties;
import java.io.FileInputStream;
import functions.App_BusinessFunctions;

public class SeleniumTC15 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));
    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));
  }

  @Test
  public void seleniumTC15() throws Exception {
	  driver.get(sAppURL);
	  //Login as a valid user
	  App_BF_Login(driver,"admin","Hi..There..001");
	  //Click on edit my profile link from homepage
	  driver.findElement(By.linkText(prop.getProperty("Lnk_Home_EditProfile"))).click();
	  //Change INVALID data & click save
	  App_BF_Edit_Profile(driver,"","","","","","","no");
	  //Compare error messages expected and actual
	  assertEquals("Please correct the following errors", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_Form_Error"))).getAttribute("value"));
	  assertEquals("Your First Name must between 2 and 50 characters", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_First_Name_Error"))).getAttribute("value"));
	  assertEquals("Your Last Name must between 2 and 50 characters", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_Last_Name_Error"))).getAttribute("value"));    
	  assertEquals("Your UTA ID must be exactly 10 digits long", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_UTA_ID_Error"))).getAttribute("value"));
	  assertEquals("Your password must between 8 and 16 characters", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_Password_Error"))).getAttribute("value"));    
	  assertEquals("Your email must between 7 and 45 characters", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_Email_Error"))).getAttribute("value"));    
	  assertEquals("Your age must be a whole number", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_Age_Error"))).getAttribute("value"));     
	  //compare success msg
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_Success_Msg"))).getAttribute("value"));   
	  
	  //enter VALID set of data to clear out errors
	  App_BF_Edit_Profile(driver,"admin","admin","1000000000","Hi..There..001","admin@aol.org","130","no");	  
	  //Compare error messages expected and actual
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_Form_Error"))).getAttribute("value"));
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_First_Name_Error"))).getAttribute("value"));
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_Last_Name_Error"))).getAttribute("value"));    
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_UTA_ID_Error"))).getAttribute("value"));
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_Password_Error"))).getAttribute("value"));    
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_Email_Error"))).getAttribute("value"));    
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_Age_Error"))).getAttribute("value"));     
	  //compare success msg
	  assertEquals("Changes successfully saved.", driver.findElement(By.name(prop.getProperty("Lbl_Edit_Own_Profile_Success_Msg"))).getAttribute("value"));   
	  
	  //Click cancel to go back to homepage
	  driver.findElement(By.name(prop.getProperty("Btn_Edit_Own_Profile_Cancel"))).click();
	  //come back to edit profile view
	  driver.findElement(By.linkText(prop.getProperty("Lnk_Home_EditProfile"))).click();
	  assertEquals("admin", driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_First_Name"))).getAttribute("value"));
	  assertEquals("admin", driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Last_Name"))).getAttribute("value"));
	  assertEquals("1000000000", driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_UTA_ID"))).getAttribute("value"));
	  assertEquals("admin", driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Username"))).getAttribute("value"));
	  assertEquals("Hi..There..001", driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Password"))).getAttribute("value"));
	  assertEquals("admin@aol.org", driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Email"))).getAttribute("value"));
	  assertEquals("130", driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Age"))).getAttribute("value"));		   
	  assertEquals("Admin", driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Role"))).getAttribute("value"));		   
	  
	  //Click logout
	  driver.findElement(By.linkText(prop.getProperty("Lnk_Edit_Own_Profile_Logout"))).click();  
  }
  
  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
