package car_rental_app.selenium.AO;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;

import car_rental_app.data.UserDAO;

import java.util.Properties;
import java.io.FileInputStream;
import functions.App_BusinessFunctions;

public class SeleniumTC08 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));

    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));

  }

  @Test
  public void seleniumTC08() throws Exception {
    driver.get(sAppURL);
    //Click register button from login page
    driver.findElement(By.id(prop.getProperty("Btn_Login_Register"))).click();
    //Enter following data and submit
    App_BF_Register(driver,"123","123","abcdefghij","@@@","thisIsntValidPass","mymymy.edu","17","yes","Manager");
    //Compare error messages expected and actual
    assertEquals("Please correct the following errors", driver.findElement(By.name(prop.getProperty("Lbl_Register_Form_Error"))).getAttribute("value"));
    assertEquals("Your First Name must only contain alphabets", driver.findElement(By.name(prop.getProperty("Lbl_Register_First_Name_Error"))).getAttribute("value"));
    assertEquals("Your Last Name must only contain alphabets", driver.findElement(By.name(prop.getProperty("Lbl_Register_Last_Name_Error"))).getAttribute("value"));    
    assertEquals("Your UTA ID must be a number", driver.findElement(By.name(prop.getProperty("Lbl_Register_UTA_ID_Error"))).getAttribute("value"));
    assertEquals("Your username must only contain alphabets and numbers", driver.findElement(By.name(prop.getProperty("Lbl_Register_Username_Error"))).getAttribute("value"));
    assertEquals("Your password must contain at least 1 upper case letter & at least 1 lower case letter & at least 1 number & at least 1 special character(@#$%^&+=._)", driver.findElement(By.name(prop.getProperty("Lbl_Register_Password_Error"))).getAttribute("value"));    
    assertEquals("Your email must contain @ and any one of the following extensions {.com .gov .net .org .edu .mil}", driver.findElement(By.name(prop.getProperty("Lbl_Register_Email_Error"))).getAttribute("value"));    
    assertEquals("You must be at least 18 years old to rent a car", driver.findElement(By.name(prop.getProperty("Lbl_Register_Age_Error"))).getAttribute("value"));    
    //Register with a valid set of data to clear the error messages and redirect to Login page
    App_BF_Register(driver,"Selenium","Tester","1098765432","testUser","Passwd.1","selenium@test.edu","25","no","Manager");
    //Login using the newly registered credentials
    App_BF_Login(driver, "testUser", "Passwd.1");
    //check header value for successful login
    assertEquals("Welcome Manager : Selenium Tester", driver.findElement(By.id(prop.getProperty("Lbl_Home_Welcome_Header"))).getText());    
    //logout
    App_BF_Logout(driver);
  }
  
  @After
  public void tearDown() throws Exception {
	UserDAO.deleteUser("testUser"); //delete test user from DB for next test
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
