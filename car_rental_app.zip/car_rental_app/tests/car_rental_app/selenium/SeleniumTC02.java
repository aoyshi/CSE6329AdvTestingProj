package car_rental_app.selenium;

import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.Properties;
import java.io.FileInputStream;
import functions.App_BusinessFunctions;

public class SeleniumTC02 extends App_BusinessFunctions {
	
  private StringBuffer verificationErrors = new StringBuffer();
  public static String sAppURL, sSharedUIMapPath; 
  
  @Before
  public void setUp() throws Exception {
    //MAGIC CODE GOES HERE 
	System.setProperty("webdriver.firefox.marionette", "C:\\GeckoSelenium\\geckodriver.exe");
    driver = new FirefoxDriver();
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    prop = new Properties();
    prop.load(new FileInputStream("./Configuration/HA_Configuration.properties"));

    sAppURL = prop.getProperty("sAppURL");
    sSharedUIMapPath = prop.getProperty("SharedUIMap");
    prop.load(new FileInputStream(sSharedUIMapPath));

  }

  @Test
  public void seleniumTC02() throws Exception {
    driver.get(sAppURL);   
    //login with correct creds
    App_BF_Login(driver,"manager","Hi..There..001");
    //check header value for successful login
    assertEquals("Welcome Manager : manager manager", driver.findElement(By.id(prop.getProperty("Lbl_Home_Welcome_Header"))).getText());    
    //logout
    App_BF_Logout(driver);
  }
  
  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}
