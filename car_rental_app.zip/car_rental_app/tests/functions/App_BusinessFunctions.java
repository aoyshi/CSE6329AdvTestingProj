package functions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Properties;

public class App_BusinessFunctions {
	
  public static WebDriver driver;
  public static Properties prop;
	
  public void App_BF_Login(WebDriver driver, String sUsername, String sPassword)
  {
	//provide user-name
	driver.findElement(By.id(prop.getProperty("Txt_Login_Username"))).clear();
	driver.findElement(By.id(prop.getProperty("Txt_Login_Username"))).sendKeys(sUsername);
	//provide password
	driver.findElement(By.id(prop.getProperty("Txt_Login_Password"))).clear();
	driver.findElement(By.id(prop.getProperty("Txt_Login_Password"))).sendKeys(sPassword);
	//click on login
	driver.findElement(By.id(prop.getProperty("Btn_Login_Login"))).click();
  }
  
  public void App_BF_Logout(WebDriver driver) {
	  //click on logout link
		driver.findElement(By.linkText(prop.getProperty("Lnk_Home_Logout"))).click();
  }
  
  public void App_BF_Register(WebDriver driver) {
	    driver.findElement(By.name("registerBtn")).click();
	    driver.findElement(By.name("firstName")).clear();
	    driver.findElement(By.name("firstName")).sendKeys("Selenium");
	    driver.findElement(By.name("lastName")).clear();
	    driver.findElement(By.name("lastName")).sendKeys("Tester");
	    driver.findElement(By.name("utaId")).clear();
	    driver.findElement(By.name("utaId")).sendKeys("1234567897");
	    driver.findElement(By.name("username")).clear();
	    driver.findElement(By.name("username")).sendKeys("selenium");
	    driver.findElement(By.name("password")).clear();
	    driver.findElement(By.name("password")).sendKeys("Passwd.1");
	    driver.findElement(By.name("email")).clear();
	    driver.findElement(By.name("email")).sendKeys("se@aol.net");
	    driver.findElement(By.name("age")).clear();
	    driver.findElement(By.name("age")).sendKeys("18");
	    driver.findElement(By.id("yes")).click();
	    driver.findElement(By.id("manager")).click();
	    driver.findElement(By.cssSelector("input[type=\"submit\"]")).click();
  }
  
}
