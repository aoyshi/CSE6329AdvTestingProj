package functions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.util.Properties;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import static org.junit.Assert.*;
import car_rental_app.data.CarDAO;
import car_rental_app.data.ReservationDAO;
import car_rental_app.model.Car;
import car_rental_app.model.ReservationDetails;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class App_BusinessFunctions {
	
  public static WebDriver driver;
  public static Properties prop;
	
  public void App_BF_Login(WebDriver driver, String sUsername, String sPassword)
  {
	//provide user-name
	driver.findElement(By.id(prop.getProperty("Txt_Login_Username"))).clear();
	driver.findElement(By.id(prop.getProperty("Txt_Login_Username"))).sendKeys(sUsername);
	//provide password
	driver.findElement(By.id(prop.getProperty("Txt_Login_Password"))).clear();
	driver.findElement(By.id(prop.getProperty("Txt_Login_Password"))).sendKeys(sPassword);
	//click on login
	driver.findElement(By.id(prop.getProperty("Btn_Login_Login"))).click();
  }
   
  public void App_BF_Logout(WebDriver driver) {
	  //click on logout link
		driver.findElement(By.linkText(prop.getProperty("Lnk_Home_Logout"))).click();
  }

  public void App_BF_Homepage(WebDriver driver){
	  //click on goto Homepage
	  driver.findElement(By.linkText(prop.getProperty("Lnk_Home_Homepage"))).click();
  }
  
  
  public void App_BF_Register(WebDriver driver, String firstName, String lastName, String utaId, 
		  String username, String password, String email, String age, String aac, String role) {
	    //enter form data
	    driver.findElement(By.name(prop.getProperty("Txt_Register_First_Name"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Register_First_Name"))).sendKeys(firstName);
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Last_Name"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Last_Name"))).sendKeys(lastName);
	    driver.findElement(By.name(prop.getProperty("Txt_Register_UTA_ID"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Register_UTA_ID"))).sendKeys(utaId);
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Username"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Username"))).sendKeys(username);
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Password"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Password"))).sendKeys(password);
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Email"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Email"))).sendKeys(email);
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Age"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Register_Age"))).sendKeys(age);
	    //choose role
	    if(role.equalsIgnoreCase("Customer"))
	    	driver.findElement(By.id(prop.getProperty("Rad_Register_Role_Customer"))).click();
	    else if (role.equalsIgnoreCase("Manager"))
	    	driver.findElement(By.id(prop.getProperty("Rad_Register_Role_Manager"))).click();
	    else
	    	driver.findElement(By.id(prop.getProperty("Rad_Register_Role_Admin"))).click();
	    //choose aac membership
	    if(aac.equalsIgnoreCase("yes"))
	    	driver.findElement(By.id(prop.getProperty("Rad_Register_AAC_Yes"))).click();
	    else
	    	driver.findElement(By.id(prop.getProperty("Rad_Register_AAC_No"))).click();
	    //submit form
	    driver.findElement(By.id(prop.getProperty("Btn_Register_Register"))).click(); 
  }
  
  public void App_BF_Add_New_Car(WebDriver driver, String carName, String capacity, String weekdayRate, 
		  String weekendRate, String weeklyRate, String dailyGps, String dailyOnstar, String dailySirius) {
	    //enter form data
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Name"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Name"))).sendKeys(carName);
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Capacity"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Capacity"))).sendKeys(capacity);
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Weekday_Rate"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Weekday_Rate"))).sendKeys(weekdayRate);
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Weekend_Rate"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Weekend_Rate"))).sendKeys(weekendRate);
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Weekly_Rate"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Weekly_Rate"))).sendKeys(weeklyRate);
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Daily_Gps"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Daily_Gps"))).sendKeys(dailyGps);
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Daily_Onstar"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Daily_Onstar"))).sendKeys(dailyOnstar);
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Daily_Sirius"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Add_Car_Daily_Sirius"))).sendKeys(dailySirius);
	    //submit form
	    driver.findElement(By.name(prop.getProperty("Btn_Add_Car_Add_Car"))).click(); 
  }
   
  public void App_BF_Revoke_Renter(WebDriver driver, String username) {
	    //enter username
	    driver.findElement(By.name(prop.getProperty("Txt_Revoke_Username"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Revoke_Username"))).sendKeys(username);
	    //submit username
	    driver.findElement(By.name(prop.getProperty("Btn_Revoke_Revoke"))).click(); 
  }
  
  public void App_BF_Find_User_Profile(WebDriver driver, String username) {
	    //enter username
	    driver.findElement(By.name(prop.getProperty("Txt_Find_Profile_Username"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Find_Profile_Username"))).sendKeys(username);
	    //search username
	    driver.findElement(By.name(prop.getProperty("Btn_Find_Profile_Search"))).click(); 
}
  
  public void App_BF_Edit_Profile(WebDriver driver, String firstName, String lastName, String utaId, 
		  String password, String email, String age, String aac) {
	    //enter form data
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_First_Name"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_First_Name"))).sendKeys(firstName);
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Last_Name"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Last_Name"))).sendKeys(lastName);
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_UTA_ID"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_UTA_ID"))).sendKeys(utaId);
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Password"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Password"))).sendKeys(password);
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Email"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Email"))).sendKeys(email);
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Age"))).clear();
	    driver.findElement(By.name(prop.getProperty("Txt_Edit_Own_Profile_Age"))).sendKeys(age);
	    //choose aac membership
	    if(aac.equalsIgnoreCase("yes"))
	    	driver.findElement(By.id(prop.getProperty("Rad_Edit_Own_Profile_AAC_Yes"))).click();
	    else
	    	driver.findElement(By.id(prop.getProperty("Rad_Edit_Own_Profile_AAC_No"))).click();
	    //submit form
	    driver.findElement(By.name(prop.getProperty("Btn_Edit_Own_Profile_Save"))).click();
	  
  }
  
  
  
  public void App_BF_ViewAllReservations(WebDriver driver) {
	  List<WebElement> table_contents= new ArrayList<>();
	  ArrayList<ReservationDetails> allReservations = new ArrayList();
	  allReservations = ReservationDAO.getAllReservations();
	  table_contents = driver.findElements(By.tagName("tr"));
	  //Check if error messages are set properly			    
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_View_All_Reservations_Form_Error"))).getAttribute("value"));
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_View_All_Reservations_Start_Error"))).getAttribute("value"));
	  assertEquals("", driver.findElement(By.name(prop.getProperty("Lbl_View_All_Reservations_End_Error"))).getAttribute("value"));
	  //Check if all records are shown
	  assertEquals(table_contents.size()-4, allReservations.size());
  }
  
  public void App_BF_ViewAllReservations_Filter(WebDriver driver,String searchStart,String searchEnd) {
	  List<WebElement> table_contents= new ArrayList<>();
	  ArrayList<ReservationDetails> allReservations = new ArrayList();
	  driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_Start"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_Start"))).sendKeys(searchStart);
	  driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_End"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_End"))).sendKeys(searchEnd);
	  driver.findElement(By.name(prop.getProperty("Btn_View_All_Reservations_Filter"))).click();
	  
	  allReservations = ReservationDAO.getAllReservationsByDate(searchStart, searchEnd);
	  table_contents = driver.findElements(By.tagName("tr"));
	  //Check if all records are shown
	  if(searchStart!="" && searchEnd!="" && driver.findElement(By.xpath("html/body/input")).getText() == "")
		  assertEquals(table_contents.size()-4, allReservations.size());
  }

  public void App_BF_ViewAvailableCars_Filter(WebDriver driver,String searchStart,String searchEnd) {
	  List<WebElement> table_contents= new ArrayList<>();
	  ArrayList<Car> allAvailableCars = new ArrayList();
	  								
	  driver.findElement(By.name(prop.getProperty("Txt_View_Available_Start"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_View_Available_Start"))).sendKeys(searchStart);
	  driver.findElement(By.name(prop.getProperty("Txt_View_Available_End"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_View_Available_End"))).sendKeys(searchEnd);
	  driver.findElement(By.name(prop.getProperty("Btn_View_Available_Search"))).click();
	  
	  allAvailableCars = CarDAO.getAllAvailableCars(searchStart, searchEnd);
	  table_contents = driver.findElements(By.tagName("tr"));
	  //Check if all records are shown
	  if(searchStart!="" && searchEnd!="" && driver.findElement(By.xpath("html/body/input")).getText() == "")
		  assertEquals(table_contents.size()-4, allAvailableCars.size());
  }
  
  public void App_BF_ViewAllCars(WebDriver driver) {
	  List<WebElement> table_contents= new ArrayList<>();
	  ArrayList<Car> allCars = new ArrayList();
	  allCars = CarDAO.getAllCars();
	  table_contents = driver.findElements(By.tagName("tr"));
	  //Check if all records are shown
	  assertEquals(table_contents.size()-1, allCars.size());
	  //Check if first record matches with the Database entry
	  if(table_contents.size()>1)
	  {
		  String carName = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[1]")).getText();
		  String capacity = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[2]")).getText();
		  String weekdayRate = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[3]")).getText();
		  String weekendRate = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[4]")).getText();
		  String weeklyRate = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[5]")).getText();
		  String gps = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[6]")).getText();
		  String onStar = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[7]")).getText();
		  String sirius = driver.findElement(By.xpath("html/body/table/tbody/tr[2]/td[8]")).getText();
		  Iterator carIter = allCars.iterator();
		  while(carIter.hasNext())
		  {
			  Car carObj = (Car)carIter.next();
			  
			  if(carObj.getName().equals(carName))
			  {
				  assertEquals(carObj.getName(),carName);
				  assertEquals(carObj.getCapacity(),Integer.parseInt(capacity));
				  assertEquals(carObj.getWeekdayRate(),Double.parseDouble(weekdayRate.replace("$", "")),0);
				  assertEquals(carObj.getWeekendRate(),Double.parseDouble(weekendRate.replace("$", "")),0);
				  assertEquals(carObj.getWeeklyRate(),Double.parseDouble(weeklyRate.replace("$", "")),0);
				  assertEquals(carObj.getDailyGps(),Double.parseDouble(gps.replace("$", "")),0);
				  assertEquals(carObj.getDailyOnstar(),Double.parseDouble(onStar.replace("$", "")),0);
				  assertEquals(carObj.getDailySirius(),Double.parseDouble(sirius.replace("$", "")),0);
			  }
		  }
		  
	  }
	  
  }
  
  public void App_BF_ViewReservationDetails(WebDriver driver,String searchStart,String searchEnd) {
	  List<WebElement> table_contents= new ArrayList<>();
	  ArrayList<ReservationDetails> allReservations = new ArrayList();
	  
	  driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_Start"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_Start"))).sendKeys(searchStart);
	  driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_End"))).clear();
	  driver.findElement(By.name(prop.getProperty("Txt_View_All_Reservations_End"))).sendKeys(searchEnd);
	  driver.findElement(By.name(prop.getProperty("Btn_View_All_Reservations_Filter"))).click();
	  
	  allReservations = ReservationDAO.getAllReservationsByDate(searchStart, searchEnd);
	  table_contents = driver.findElements(By.tagName("tr"));
	  //Check if all records are shown
	  if(searchStart!="" && searchEnd!="" && driver.findElement(By.xpath("html/body/input")).getText() == "" && table_contents.size()-4 != 0)
	  {
		  String allRev_renter = driver.findElement(By.xpath("html/body/table[2]/tbody/tr[2]/td[1]")).getText();
		  String allRev_car = driver.findElement(By.xpath("html/body/table[2]/tbody/tr[2]/td[2]")).getText();
		  String allRev_checkOut = driver.findElement(By.xpath("html/body/table[2]/tbody/tr[2]/td[3]")).getText();
		  String allRev_returnBy = driver.findElement(By.xpath("html/body/table[2]/tbody/tr[2]/td[4]")).getText();
		  String allRev_totalPrice = driver.findElement(By.xpath("html/body/table[2]/tbody/tr[2]/td[5]")).getText();
		  driver.findElement(By.linkText(prop.getProperty("Lnk_View_All_Reservations_View"))).click();
		  
		  WebDriverWait myWaitVar = new WebDriverWait(driver,10);
		  myWaitVar.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[1]/td[1]")));
		  //Check Title of Page
		  assertEquals("View Reservation Details",driver.getTitle());
		  //Check if Correct details are carried to the details page
		  assertEquals(allRev_renter,driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[1]/td[2]")).getText());
		  assertEquals(allRev_car,driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[2]/td[2]")).getText());
		  assertEquals(allRev_checkOut,driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[4]/td[2]")).getText());
		  assertEquals(allRev_returnBy,driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[5]/td[2]")).getText());
		  assertEquals(allRev_totalPrice,driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[6]/td[2]")).getText());
		  
		  //Check if data is same as DB
		  Iterator iter = allReservations.iterator();
		  while(iter.hasNext())
		  {
			  ReservationDetails rsdet = (ReservationDetails)iter.next();
			  int resID = Integer.parseInt(driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[8]/td[2]")).getText());
			  if(rsdet.getId()==resID)
			  {
				  assertEquals(rsdet.getUsername(), driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[1]/td[2]")).getText());
				  assertEquals(rsdet.getCarName(), driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[2]/td[2]")).getText());
				  assertEquals(rsdet.getCapacity(), driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[3]/td[2]")).getText());
				  assertEquals(rsdet.getStartTime(), driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[4]/td[2]")).getText());
				  assertEquals(rsdet.getEndTime(), driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[5]/td[2]")).getText());
				  assertEquals(rsdet.getTotalPrice(), driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[6]/td[2]")).getText());
				  assertEquals(rsdet.getAdditionalFeatures(), driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[7]/td[2]")).getText());
				  assertEquals(rsdet.getId(), driver.findElement(By.xpath("html/body/table/tbody/tr/td/form/table/tbody/tr[8]/td[2]")).getText());
			  }
		  }
	  }
  }
   
}
